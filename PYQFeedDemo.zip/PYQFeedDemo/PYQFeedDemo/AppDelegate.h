//
//  AppDelegate.h
//  PYQFeedDemo
//
//  Created by 陈浩 on 16/7/10.
//  Copyright © 2016年 陈浩. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

