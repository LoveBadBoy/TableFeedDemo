//
//  ZPFileManager.h
//  Records
//
//  Created by 陈浩 on 15/11/10.
//  Copyright © 2015年 陈浩. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZPFileManager : NSObject

+ (NSString *)libCachesPath:(NSString *)directory;

@end
